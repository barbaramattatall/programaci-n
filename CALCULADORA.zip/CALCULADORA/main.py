from formulario.form_calculadora import FormularioCalculadora
 
app = FormularioCalculadora()
app.mainloop()
